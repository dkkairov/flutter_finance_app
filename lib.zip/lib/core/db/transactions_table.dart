import 'package:drift/drift.dart';

class TransactionsTable extends Table {
  // Существующие колонки
  // id с autoIncrement автоматически становится первичным ключом
  IntColumn get id => integer().autoIncrement()(); // Локальный ID

  IntColumn get serverId => integer().nullable()(); // Серверный ID
  IntColumn get userId => integer()(); // ID пользователя

  // Колонка для типа транзакции (хранится как строка)
  TextColumn get transactionType => text()(); // 'expense', 'income', 'transfer'

  IntColumn get transactionCategoryId => integer().nullable()(); // ID категории (nullable, т.к. для перевода его нет)
  RealColumn get amount => real()(); // Сумма
  // accountId используется для счета в expense/income. Делаем его nullable, т.к. для перевода он не используется напрямую.
  IntColumn get accountId => integer().nullable()();
  IntColumn get projectId => integer().nullable()(); // Проект (nullable)
  TextColumn get description => text().nullable()(); // Описание (nullable)
  DateTimeColumn get date => dateTime()(); // Дата и время
  BoolColumn get isActive => boolean().withDefault(const Constant(true))(); // Флаг активности

  // Колонки для счетов перевода
  IntColumn get fromAccountId => integer().nullable()(); // ID счета отправителя
  IntColumn get toAccountId => integer().nullable()(); // ID счета получателя

// Возможно, здесь есть foreign keys к таблице счетов или другие ограничения
// Например:
// ForeignKey get fromAccountId => integer().nullable().references(Accounts, #id)();
// ForeignKey get toAccountId => integer().nullable().references(Accounts, #id)();

// Добавьте другие ваши индексы или ограничения, если они были

// !!! ИСПРАВЛЕНО: Удален явный геттер primaryKey
// @override
// Set<Column> get primaryKey => {id}; // Эта строка удалена

}