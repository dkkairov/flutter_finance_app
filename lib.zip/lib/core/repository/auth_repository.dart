// import 'package:flutter_riverpod/flutter_riverpod.dart';
//
// final authRepositoryProvider = Provider<AuthRepository>((ref) {
//   return AuthRepository();
// });
//
// class AuthRepository {
//   String? getAuthToken() {
//     // Здесь должна быть логика получения токена (например, из хранилища)
//     return "your_bearer_token"; // Замените на реальный токен
//   }
// }